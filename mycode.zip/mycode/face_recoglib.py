import cv2
import face_recognition
import numpy as np
img = cv2.imread("mycode/myimg/1.jpg")
image = []
fb = []
l = 4
for i in range(l):
    image.append(face_recognition.load_image_file("mycode/myimg/"+ str(i)+".jpg"))

for i in range(l):
    fb.append(face_recognition.face_encodings(image[i].copy())[0])


for i in range(l):
    results = face_recognition.compare_faces([fb[2]], fb[i])
    print(results)


# def draw_rects(img, rects, color):
#     for x1, y1, x2, y2 in rects:
#         cv2.rectangle(img, (x1, y1), (x2, y2), color, 5)


# for i in range(len(frect)):
#     list(frect[i])[2:] += list(frect[i])[:2]
# draw_rects(image, frect, (0, 0, 255))


# cv2.namedWindow("image",cv2.WINDOW_NORMAL)
# cv2.resizeWindow("image",(640,480))

# cv2.namedWindow("img",cv2.WINDOW_NORMAL)
# cv2.resizeWindow("img",(640,480))

# while True:
        
#         cv2.imshow('image', image)
#         cv2.imshow('img', img)
#         if cv2.waitKey(5) == 27:
#             break
# cv2.destroyAllWindows()
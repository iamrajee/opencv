#!/usr/bin/env python

from __future__ import print_function

import numpy as np
import cv2 as cv

def detect(img, cascade):
    rects = cascade.detectMultiScale(img, scaleFactor=1.3, minNeighbors=4, minSize=(30, 30),
                                     flags=cv.CASCADE_SCALE_IMAGE)
    if len(rects) == 0:
        return []
    
    rects[:,2:] += rects[:,:2]
    return rects

def draw_rects(img, rects, color):
    for x1, y1, x2, y2 in rects:
        cv.rectangle(img, (x1, y1), (x2, y2), color, 2)

if __name__ == '__main__':
    import sys, getopt

    # args, video_src = getopt.getopt(sys.argv[1:], '', ['cascade=', 'nested-cascade=','smile-cascade=','any-cascade='])
    # args = dict(args)
    # cascade_fn = args.get('--cascade', "data/haarcascades/haarcascade_frontalface_alt.xml")
    # _fn  = args.get('--nested-cascade', "data/haarcascades/haarcascade_eye.xml")
    # smilexml  = args.get('--smile-cascade', "data/haarcascades/haarcascade_smile.xml")
    # anyxml  = args.get('--any-cascade', "data/haarcascades/haarcascade_frontalface_default.xml")

    face_cascade = cv.CascadeClassifier("data/haarcascades/haarcascade_frontalface_alt.xml")
    eye_cascade = cv.CascadeClassifier("data/haarcascades/haarcascade_eye.xml")
    smile_cascade = cv.CascadeClassifier("data/haarcascades/haarcascade_smile.xml")
    any_cascade = cv.CascadeClassifier("data/haarcascades/haarcascade_frontalface_default.xml")
    cam = cv.VideoCapture(-1)
    while True:
        ret, img = cam.read()
        gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
        gray = cv.equalizeHist(gray)
        cv.imshow('gray', gray)
        frects = detect(gray, face_cascade)
        imgcopy = img.copy()
        draw_rects(imgcopy, frects, (0, 255, 0))
        if not eye_cascade.empty():
            for x1, y1, x2, y2 in frects:
                graycroped = gray[y1:y2, x1:x2]
                imgcopycroped = imgcopy[y1:y2, x1:x2]
                erects = detect(graycroped.copy(), eye_cascade)
                draw_rects(imgcopycroped, erects, (255, 0, 0))
        if not smile_cascade.empty():
            for x1, y1, x2, y2 in frects:
                graycroped = gray[y1:y2, x1:x2]
                imgcopycroped = imgcopy[y1:y2, x1:x2]
                srects = detect(graycroped.copy(), smile_cascade)
                if len(srects)>1:
                    srects = [srects[0]]
                draw_rects(imgcopycroped, srects, (0, 0, 255))
        cv.imshow('facedetect', imgcopy)

        if cv.waitKey(5) == 27:
            break
    cv.destroyAllWindows()
